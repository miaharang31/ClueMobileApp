package cs309;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
